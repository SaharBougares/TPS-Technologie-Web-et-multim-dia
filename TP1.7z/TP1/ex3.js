const user = { name: "Noor", age: 10, city: "Tunis" };

let name = user.name;
let age = user.age;

console.log(name); 
console.log(age);  
